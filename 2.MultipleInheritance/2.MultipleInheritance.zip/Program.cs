﻿using System;


public class Program
{
    static void Main(string[] args)
    {
        {
            
            //Puppy puppy = new Puppy();
            //puppy.Eat();
            //puppy.Bark();
            //puppy.Weep();
        }
    }
}

