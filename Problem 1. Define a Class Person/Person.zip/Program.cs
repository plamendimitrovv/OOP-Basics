﻿using System;

namespace Problem_1._Define_a_Class_Person
{
    class Program
    {
        static void Main(string[] args)
        {
           

        }
    }
}
