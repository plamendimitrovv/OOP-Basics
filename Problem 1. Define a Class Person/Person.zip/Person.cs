﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem_1._Define_a_Class_Person
{
    class Person
    {

    }
}
