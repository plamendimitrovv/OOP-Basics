﻿public interface IIdentible
{
    string Id { get; }
}

